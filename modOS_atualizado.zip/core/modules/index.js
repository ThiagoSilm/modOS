module.exports = () => {
    console.log("Módulo de exemplo executado!");
};